package Model;

public abstract class FigureAbs {

    public abstract double getArea();

    public abstract double getPerimeter();

}
